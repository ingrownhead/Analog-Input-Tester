#include <3ds.h>
#include <stdio.h>

int main() {
    gfxInitDefault();
    PrintConsole topScreen;
    consoleInit(GFX_TOP, &topScreen);
    consoleSelect(&topScreen);

    // Print static labels once
    printf("=== Analog Input Tester v1.0.0-beta ===\n\n");
    printf("C-Stick X:    \n");
    printf("C-Stick Y:    \n");
    printf("\n");
    printf("Circle Pad X: \n");
    printf("Circle Pad Y: \n");
    printf("\n");
    printf("Buttons:      \n");
    printf("\n");
    printf("Press START to exit\n");

    while (aptMainLoop()) {
        hidScanInput();

        circlePosition cstick;
        hidCstickRead(&cstick);

        circlePosition cpad;
        hidCircleRead(&cpad);

        u32 keys = hidKeysHeld();

        if (keys & KEY_START) break;

        // Move cursor to value positions and overwrite only numbers
        printf("\x1b[3;11H%4d  ", cstick.dx);
        printf("\x1b[4;11H%4d  ", cstick.dy);
        printf("\x1b[6;11H%4d  ", cpad.dx);
        printf("\x1b[7;11H%4d  ", cpad.dy);
        printf("\x1b[9;9H%10lu  ", keys);

        gspWaitForVBlank();
        gfxFlushBuffers();
        gfxSwapBuffers();
    }

    gfxExit();
    return 0;
}
