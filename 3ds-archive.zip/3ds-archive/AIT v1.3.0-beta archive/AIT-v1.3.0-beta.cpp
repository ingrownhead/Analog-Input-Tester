#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>
#include <stdarg.h>
#include <vector>
#include <cmath>
#define APP_NAME        "Analog Input Tester"
#define APP_VERSION     "1.3.0-beta"
#define OUTLINE         3
#define DISPLAY_RADIUS  80.0f
#define DOT_RADIUS      6.0f
#define TRAIL_MAX       200
#define CPAD_CENTER_X   80.0f
#define CPAD_CENTER_Y   120.0f
#define CSTICK_CENTER_X 240.0f
#define CSTICK_CENTER_Y 120.0f
// Motion page z-layers — controls draw ordering (higher = in front)
#define Z_CUBE_BACK     0.15f   // back face
#define Z_CROSS         0.50f   // accel cross — sits between back and front face
#define Z_CUBE_FRONT    0.75f   // front face
#define Z_CUBE_VERTS    0.85f   // vertices on top of everything
enum AppPages { PAGE_STICKS, PAGE_TOUCH, PAGE_MOTION };
int currentPage = PAGE_STICKS;
bool isCalibrated = false, isSampling = false;
int sampleCounter = 0;
float gyroSumX = 0, gyroSumY = 0, gyroDriftX = 0, gyroDriftY = 0;
float rotX = 0, rotY = 0, rotZ = 0; // rotZ accumulated, not yet applied to cube
struct TrailPoint { float x; float y; };
std::vector<TrailPoint> touchTrail;
float cube_points[8][3] = {
    {-30,-30, 30}, {30,-30, 30}, {30, 30, 30}, {-30, 30, 30},
    {-30,-30,-30}, {30,-30,-30}, {30, 30,-30}, {-30, 30,-30}
};
C2D_TextBuf g_textBuf;
// Draw a horizontal bar centered at midX, handling negative values correctly.
// DrawRectSolid requires positive width — compute origin from sign of value.
static inline void drawBar(float midX, float y, float z, float value, float scale, float h, u32 color) {
    float len = value / scale;
    if (len > 0.0f)
        C2D_DrawRectSolid(midX,       y, z,  len, h, color);
    else if (len < 0.0f)
        C2D_DrawRectSolid(midX + len, y, z, -len, h, color);
}
// Draw formatted text using C2D_Text
static void drawTextF(float x, float y, float z, float sx, float sy, u32 color, const char* fmt, ...) {
    char buf[256];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    C2D_Text text;
    C2D_TextParse(&text, g_textBuf, buf);
    C2D_TextOptimize(&text);
    C2D_DrawText(&text, C2D_WithColor, x, y, z, sx, sy, color);
}
int main() {
    gfxInitDefault();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();
    HIDUSER_EnableAccelerometer();
    HIDUSER_EnableGyroscope();
    C3D_RenderTarget* topLeft  = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    C3D_RenderTarget* topRight = C2D_CreateScreenTarget(GFX_TOP, GFX_RIGHT);
    C3D_RenderTarget* bot      = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);
    g_textBuf = C2D_TextBufNew(4096);
    u32 gray   = C2D_Color32(128, 128, 128, 255);
    u32 black  = C2D_Color32(  0,   0,   0, 255);
    u32 red    = C2D_Color32(255,   0,   0, 255);
    u32 white  = C2D_Color32(255, 255, 255, 255);
    u32 green  = C2D_Color32(  0, 255,   0, 255);
    u32 yellow    = C2D_Color32(255, 255,   0, 255);
    u32 blue      = C2D_Color32(  0, 128, 255, 255);
    // 12 edges of the cube — each has one static color
    int cubeEdges[12][2] = {
        {0,1}, {1,2}, {2,3}, {3,0},  // front face edges
        {4,5}, {5,6}, {6,7}, {7,4},  // back face edges
        {0,4}, {1,5}, {2,6}, {3,7},  // pillar edges
    };
    u32 edgeColors[12] = {
        C2D_Color32(255,  60,  60, 255), C2D_Color32(255,  60,  60, 255), // front — red
        C2D_Color32(255,  60,  60, 255), C2D_Color32(255,  60,  60, 255),
        C2D_Color32( 60, 120, 255, 255), C2D_Color32( 60, 120, 255, 255), // back  — blue
        C2D_Color32( 60, 120, 255, 255), C2D_Color32( 60, 120, 255, 255),
        C2D_Color32( 60, 255,  60, 255), C2D_Color32(200,  60, 255, 255), // pillars: green, purple,
        C2D_Color32(255, 255,  60, 255), C2D_Color32(  0, 220, 220, 255), //          yellow, cyan
    };
    while (aptMainLoop()) {
        hidScanInput();
        u32 kDown = hidKeysDown(), kHeld = hidKeysHeld();
        if (kDown & KEY_START) break;
        // Page navigation
        if (kDown & (KEY_L | KEY_R)) {
            if (kDown & KEY_R) currentPage = (currentPage + 1) % 3;
            if (kDown & KEY_L) currentPage = (currentPage + 2) % 3;
            if (currentPage == PAGE_MOTION) { isCalibrated = false; isSampling = false; }
        }
        circlePosition cstick, cpad;
        hidCstickRead(&cstick);
        hidCircleRead(&cpad);
        touchPosition touch; hidTouchRead(&touch);
        accelVector accel;   hidAccelRead(&accel);
        angularRate gyro;    hidGyroRead(&gyro);
        // Gyro calibration: sample 30 frames at rest to compute drift offset
        if (currentPage == PAGE_MOTION && (kDown & KEY_A) && !isSampling) {
            isSampling = true; sampleCounter = 0;
            gyroSumX = 0; gyroSumY = 0;
            rotX = 0; rotY = 0; rotZ = 0;
        }
        if (isSampling) {
            gyroSumX += (float)gyro.x;
            gyroSumY += (float)gyro.y;
            sampleCounter++;
            if (sampleCounter >= 30) {
                gyroDriftX = gyroSumX / 30.0f;
                gyroDriftY = gyroSumY / 30.0f;
                isSampling = false; isCalibrated = true;
            }
        }
        if (isCalibrated) {
            float moveX = (float)gyro.x - gyroDriftX;
            float moveY = (float)gyro.y - gyroDriftY;
            // Dead zone: suppress residual drift noise after calibration
            if (fabsf(moveX) < 4.0f) moveX = 0.0f;
            if (fabsf(moveY) < 4.0f) moveY = 0.0f;
            rotX += moveX * 0.0002f;
            rotY += moveY * 0.0002f;
            rotZ += (float)gyro.z * 0.0002f;
        }
        C2D_TextBufClear(g_textBuf);
        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
        // ======== Bottom screen ========
        C2D_TargetClear(bot, black);
        C2D_SceneBegin(bot);
        if (currentPage == PAGE_STICKS) {
            // Circle pad (left) ----------------------------------------
            C2D_DrawCircleSolid(CPAD_CENTER_X, CPAD_CENTER_Y, 0.10f, DISPLAY_RADIUS, gray);
            C2D_DrawCircleSolid(CPAD_CENTER_X, CPAD_CENTER_Y, 0.10f, DISPLAY_RADIUS - OUTLINE, black);
            C2D_DrawLine(CPAD_CENTER_X - DISPLAY_RADIUS, CPAD_CENTER_Y, white,
                         CPAD_CENTER_X + DISPLAY_RADIUS, CPAD_CENTER_Y, white, 1.0f, 0.3f);
            C2D_DrawLine(CPAD_CENTER_X, CPAD_CENTER_Y - DISPLAY_RADIUS, white,
                         CPAD_CENTER_X, CPAD_CENTER_Y + DISPLAY_RADIUS, white, 1.0f, 0.3f);
            C2D_DrawCircleSolid(CPAD_CENTER_X, CPAD_CENTER_Y, 0.40f, 3.0f, green);
            C2D_DrawCircleSolid(
                CPAD_CENTER_X + (cpad.dx / 155.0f) * DISPLAY_RADIUS,
                CPAD_CENTER_Y - (cpad.dy / 155.0f) * DISPLAY_RADIUS,
                0.50f, DOT_RADIUS, red);
            // C-stick (right) ------------------------------------------
            C2D_DrawRectSolid(CSTICK_CENTER_X - 80, CSTICK_CENTER_Y - 80, 0.10f, 160, 160, gray);
            C2D_DrawRectSolid(CSTICK_CENTER_X - 77, CSTICK_CENTER_Y - 77, 0.10f, 154, 154, black);
            C2D_DrawLine(CSTICK_CENTER_X - 80, CSTICK_CENTER_Y, white,
                         CSTICK_CENTER_X + 80, CSTICK_CENTER_Y, white, 1.0f, 0.3f);
            C2D_DrawLine(CSTICK_CENTER_X, CSTICK_CENTER_Y - 80, white,
                         CSTICK_CENTER_X, CSTICK_CENTER_Y + 80, white, 1.0f, 0.3f);
            C2D_DrawCircleSolid(CSTICK_CENTER_X, CSTICK_CENTER_Y, 0.40f, 3.0f, green);
            C2D_DrawCircleSolid(
                CSTICK_CENTER_X + (cstick.dx / 146.0f) * DISPLAY_RADIUS,
                CSTICK_CENTER_Y - (cstick.dy / 146.0f) * DISPLAY_RADIUS,
                0.50f, DOT_RADIUS, red);
        } else if (currentPage == PAGE_TOUCH) {
            if (kHeld & KEY_TOUCH) {
                if ((int)touchTrail.size() >= TRAIL_MAX)
                    touchTrail.erase(touchTrail.begin());
                touchTrail.push_back({(float)touch.px, (float)touch.py});
                C2D_DrawCircleSolid(touch.px, touch.py, 0.9f, DOT_RADIUS, yellow);
            } else {
                touchTrail.clear();
            }
            for (size_t i = 1; i < touchTrail.size(); i++)
                C2D_DrawLine(touchTrail[i-1].x, touchTrail[i-1].y, yellow,
                             touchTrail[i].x,   touchTrail[i].y,   yellow, 2.0f, 0.5f);
        } else if (currentPage == PAGE_MOTION) {
            // Bottom screen for motion: text readouts + gyro bars
            drawTextF(4, 4, 0.9f, 0.5f, 0.5f, white, "=== %s %s ===", APP_NAME, APP_VERSION);
            drawTextF(4, 20, 0.9f, 0.5f, 0.5f, white, "Page 3/3: Motion | A: Calibrate");
            if (isSampling) {
                drawTextF(4, 44, 0.9f, 0.5f, 0.5f, yellow, "[ CALIBRATING: %d%% ]", (sampleCounter * 100) / 30);
            } else if (!isCalibrated) {
                drawTextF(4, 44, 0.9f, 0.5f, 0.5f, yellow, "[ CALIBRATION REQUIRED ]");
                drawTextF(4, 62, 0.9f, 0.5f, 0.5f, white, "Place 3DS on a flat, static");
                drawTextF(4, 78, 0.9f, 0.5f, 0.5f, white, "surface and press (A)");
            } else {
                float gx = (float)gyro.x - gyroDriftX;
                float gy = (float)gyro.y - gyroDriftY;
                float gz = (float)gyro.z;
                drawTextF(4, 44, 0.9f, 0.5f, 0.5f, white, "Gyro(c): X:%5.0f Y:%5.0f Z:%5d", gx, gy, gyro.z);
                drawTextF(4, 62, 0.9f, 0.5f, 0.5f, white, "Accel:   X:%4d  Y:%4d  Z:%4d", accel.x, accel.y, accel.z);
                drawTextF(4, 80, 0.9f, 0.5f, 0.5f, gray, "3D Slider: %.2f", osGet3DSliderState());
                float midX = 160.0f;
                // Center reference line
                C2D_DrawRectSolid(midX - 1, 188, 0.3f, 2, 42, gray);
                // Color indicators (left side)
                C2D_DrawRectSolid(10, 192, 0.9f, 5, 8, red);
                C2D_DrawRectSolid(10, 204, 0.9f, 5, 8, green);
                C2D_DrawRectSolid(10, 216, 0.9f, 5, 8, blue);
                // Bars — scale 12.0 matches original v1.2.4 range
                drawBar(midX, 192, 0.7f, gx, 12.0f, 8, red);
                drawBar(midX, 204, 0.7f, gy, 12.0f, 8, green);
                drawBar(midX, 216, 0.7f, gz, 12.0f, 8, blue);
            }
        }
        // --- Top screen: stereo 3D cube (motion page only) ---
        if (currentPage == PAGE_MOTION && isCalibrated) {
            float slider = osGet3DSliderState();
            float eyeSep = slider * 15.0f; // max eye separation in pixels
            // Cube rotation: integrated gyro + accelerometer gravity tilt blend
            float fX = rotX + (accel.y * 0.0015f);
            float fY = rotY + (accel.x * 0.0015f);
            // Render once per eye (left then right)
            for (int eye = 0; eye < 2; eye++) {
                C3D_RenderTarget* target = (eye == 0) ? topLeft : topRight;
                float eyeShift = (eye == 0) ? -eyeSep * 0.5f : eyeSep * 0.5f;
                C2D_TargetClear(target, black);
                C2D_SceneBegin(target);
                // Origin: top screen is 400x240; center with jolt offset
                float jX = 200.0f + (accel.x / 40.0f) + eyeShift;
                float jY = 120.0f + (accel.y / 40.0f);
                float s = 1.8f, p[8][3];
                float pscale[8];
                float focalLen = 250.0f;
                for (int i = 0; i < 8; i++) {
                    float px = cube_points[i][0] * s;
                    float py = cube_points[i][1] * s;
                    float pz = cube_points[i][2] * s;
                    float ry = py * cosf(fX) - pz * sinf(fX);
                    float rz = py * sinf(fX) + pz * cosf(fX);
                    float rx = px * cosf(fY) + rz * sinf(fY);
                    float rZfinal = -px * sinf(fY) + rz * cosf(fY);
                    float ps = focalLen / (focalLen - rZfinal);
                    pscale[i] = ps;
                    p[i][0] = rx * ps + jX;
                    p[i][1] = ry * ps + jY;
                    p[i][2] = rZfinal;
                }
                // Sort 12 edges back-to-front by average Z
                float meanZ = 0;
                for (int i = 0; i < 8; i++) meanZ += p[i][2];
                meanZ /= 8.0f;
                float edgeAvgZ[12];
                int edgeOrder[12] = {0,1,2,3,4,5,6,7,8,9,10,11};
                for (int ei = 0; ei < 12; ei++)
                    edgeAvgZ[ei] = (p[cubeEdges[ei][0]][2] + p[cubeEdges[ei][1]][2]) * 0.5f;
                for (int i = 0; i < 11; i++)
                    for (int j = i+1; j < 12; j++)
                        if (edgeAvgZ[edgeOrder[i]] > edgeAvgZ[edgeOrder[j]]) {
                            int tmp = edgeOrder[i];
                            edgeOrder[i] = edgeOrder[j];
                            edgeOrder[j] = tmp;
                        }
                // Draw edges back-to-front; cross at Z_CROSS
                bool crossDrawn = false;
                for (int idx = 0; idx < 12; idx++) {
                    int ei = edgeOrder[idx];
                    float zLayer = Z_CUBE_BACK + (Z_CUBE_FRONT - Z_CUBE_BACK) * (idx / 11.0f);
                    if (!crossDrawn && edgeAvgZ[ei] > meanZ) {
                        C2D_DrawRectSolid(jX - 40, jY - 3, Z_CROSS, 80, 6, green);
                        C2D_DrawRectSolid(jX -  3, jY - 40, Z_CROSS, 6, 80, red);
                        crossDrawn = true;
                    }
                    int v0 = cubeEdges[ei][0], v1 = cubeEdges[ei][1];
                    float tw = (pscale[v0] + pscale[v1]) * 0.5f;
                    u32 ec = edgeColors[ei];
                    C2D_DrawLine(p[v0][0], p[v0][1], ec,
                                 p[v1][0], p[v1][1], ec, 2.5f * tw, zLayer);
                }
                if (!crossDrawn) {
                    C2D_DrawRectSolid(jX - 40, jY - 3, Z_CROSS, 80, 6, red);
                    C2D_DrawRectSolid(jX -  3, jY - 40, Z_CROSS, 6, 80, green);
                }
                // Vertices
                for (int i = 0; i < 8; i++) {
                    float vz = (p[i][2] > meanZ) ? Z_CUBE_VERTS : Z_CUBE_BACK + 0.03f;
                    C2D_DrawCircleSolid(p[i][0], p[i][1], vz, 4.0f * pscale[i], white);
                }
            }
        } else {
            // Non-cube pages: text info on top screen (both eyes identical)
            for (int eye = 0; eye < 2; eye++) {
                C3D_RenderTarget* target = (eye == 0) ? topLeft : topRight;
                C2D_TargetClear(target, black);
                C2D_SceneBegin(target);
                drawTextF(8, 8, 0.9f, 0.5f, 0.5f, white, "=== %s %s ===", APP_NAME, APP_VERSION);
                drawTextF(8, 26, 0.9f, 0.5f, 0.5f, white, "Page %d/3: %s%s",
                    currentPage + 1,
                    currentPage == PAGE_STICKS ? "Sticks" :
                    currentPage == PAGE_TOUCH  ? "Touch"  : "Motion",
                    currentPage == PAGE_MOTION ? " | A: Calibrate" : "");
                if (currentPage == PAGE_MOTION) {
                    // Pre-calibration: show instructions on top screen too
                    if (isSampling) {
                        drawTextF(8, 50, 0.9f, 0.5f, 0.5f, yellow, "[ CALIBRATING: %d%% ]",
                            (sampleCounter * 100) / 30);
                    } else {
                        drawTextF(8, 50, 0.9f, 0.5f, 0.5f, yellow, "[ CALIBRATION REQUIRED ]");
                        drawTextF(8, 68, 0.9f, 0.5f, 0.5f, white, "Place 3DS on a flat, static");
                        drawTextF(8, 84, 0.9f, 0.5f, 0.5f, white, "surface and press (A)");
                    }
                } else {
                    drawTextF(8, 50, 0.9f, 0.5f, 0.5f, white, "CPad:   %4d %4d | CStick: %4d %4d",
                        cpad.dx, cpad.dy, cstick.dx, cstick.dy);
                    drawTextF(8, 74, 0.9f, 0.5f, 0.5f, white, "Touch: X:%3d Y:%3d  | Keys:  %08lX",
                        touch.px, touch.py, kHeld);
                }
            }
        }
        C3D_FrameEnd(0);
    }
    C2D_TextBufDelete(g_textBuf);
    HIDUSER_DisableAccelerometer();
    HIDUSER_DisableGyroscope();
    C2D_Fini();
    C3D_Fini();
    gfxExit();
    return 0;
}

