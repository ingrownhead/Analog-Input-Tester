#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>
#include <vector>
#include <cmath>
#define APP_NAME        "Analog Input Tester"
#define APP_VERSION     "1.2.5-beta"
#define OUTLINE         3
#define DISPLAY_RADIUS  80.0f
#define DOT_RADIUS      6.0f
#define TRAIL_MAX       200
#define CPAD_CENTER_X   80.0f
#define CPAD_CENTER_Y   120.0f
#define CSTICK_CENTER_X 240.0f
#define CSTICK_CENTER_Y 120.0f
// Motion page z-layers — controls draw ordering (higher = in front)
#define Z_CUBE_BACK     0.15f   // back face
#define Z_CROSS         0.50f   // accel cross — sits between back and front face
#define Z_CUBE_FRONT    0.75f   // front face
#define Z_CUBE_VERTS    0.85f   // vertices on top of everything
enum AppPages { PAGE_STICKS, PAGE_TOUCH, PAGE_MOTION };
int currentPage = PAGE_STICKS;
bool isCalibrated = false, isSampling = false;
int sampleCounter = 0;
float gyroSumX = 0, gyroSumY = 0, gyroDriftX = 0, gyroDriftY = 0;
float rotX = 0, rotY = 0, rotZ = 0; // rotZ accumulated, not yet applied to cube
struct TrailPoint { float x; float y; };
std::vector<TrailPoint> touchTrail;
float cube_points[8][3] = {
    {-30,-30, 30}, {30,-30, 30}, {30, 30, 30}, {-30, 30, 30},
    {-30,-30,-30}, {30,-30,-30}, {30, 30,-30}, {-30, 30,-30}
};
// Draw a horizontal bar centered at midX, handling negative values correctly.
// DrawRectSolid requires positive width — compute origin from sign of value.
static inline void drawBar(float midX, float y, float z, float value, float scale, float h, u32 color) {
    float len = value / scale;
    if (len > 0.0f)
        C2D_DrawRectSolid(midX,       y, z,  len, h, color);
    else if (len < 0.0f)
        C2D_DrawRectSolid(midX + len, y, z, -len, h, color);
}
int main() {
    gfxInitDefault();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();
    HIDUSER_EnableAccelerometer();
    HIDUSER_EnableGyroscope();
    PrintConsole topScreen;
    consoleInit(GFX_TOP, &topScreen);
    C3D_RenderTarget* bot = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);
    u32 gray   = C2D_Color32(128, 128, 128, 255);
    u32 black  = C2D_Color32(  0,   0,   0, 255);
    u32 red    = C2D_Color32(255,   0,   0, 255);
    u32 white  = C2D_Color32(255, 255, 255, 255);
    u32 green  = C2D_Color32(  0, 255,   0, 255);
    u32 yellow    = C2D_Color32(255, 255,   0, 255);
    u32 blue      = C2D_Color32(  0, 128, 255, 255);
    // Cube face colors — one per side for consistent coloring
    u32 faceColors[6] = {
        C2D_Color32(255,  60,  60, 255), // face 0 (front)  — red
        C2D_Color32( 60, 120, 255, 255), // face 1 (back)   — blue
        C2D_Color32( 60, 255,  60, 255), // face 2 (top)    — green
        C2D_Color32(255, 255,  60, 255), // face 3 (bottom) — yellow
        C2D_Color32(  0, 220, 220, 255), // face 4 (left)   — cyan
        C2D_Color32(200,  60, 255, 255), // face 5 (right)  — purple
    };
    // 6 faces of the cube defined by vertex indices
    int cubeFaces[6][4] = {
        {0, 1, 2, 3}, // front  (z = +30)
        {5, 4, 7, 6}, // back   (z = -30)
        {0, 1, 5, 4}, // top    (y = -30)
        {3, 2, 6, 7}, // bottom (y = +30)
        {0, 3, 7, 4}, // left   (x = -30)
        {1, 2, 6, 5}, // right  (x = +30)
    };
    while (aptMainLoop()) {
        hidScanInput();
        u32 kDown = hidKeysDown(), kHeld = hidKeysHeld();
        if (kDown & KEY_START) break;
        // Page navigation
        if (kDown & (KEY_L | KEY_R)) {
            if (kDown & KEY_R) currentPage = (currentPage + 1) % 3;
            if (kDown & KEY_L) currentPage = (currentPage + 2) % 3;
            consoleClear();
            if (currentPage == PAGE_MOTION) { isCalibrated = false; isSampling = false; }
        }
        circlePosition cstick, cpad;
        hidCstickRead(&cstick);
        hidCircleRead(&cpad);
        touchPosition touch; hidTouchRead(&touch);
        accelVector accel;   hidAccelRead(&accel);
        angularRate gyro;    hidGyroRead(&gyro);
        // Gyro calibration: sample 30 frames at rest to compute drift offset
        if (currentPage == PAGE_MOTION && (kDown & KEY_A) && !isSampling) {
            isSampling = true; sampleCounter = 0;
            gyroSumX = 0; gyroSumY = 0;
            rotX = 0; rotY = 0; rotZ = 0;
            consoleClear();
        }
        if (isSampling) {
            gyroSumX += (float)gyro.x;
            gyroSumY += (float)gyro.y;
            sampleCounter++;
            if (sampleCounter >= 30) {
                gyroDriftX = gyroSumX / 30.0f;
                gyroDriftY = gyroSumY / 30.0f;
                isSampling = false; isCalibrated = true;
                consoleClear();
            }
        }
        if (isCalibrated) {
            float moveX = (float)gyro.x - gyroDriftX;
            float moveY = (float)gyro.y - gyroDriftY;
            // Dead zone: suppress residual drift noise after calibration
            if (fabsf(moveX) < 4.0f) moveX = 0.0f;
            if (fabsf(moveY) < 4.0f) moveY = 0.0f;
            rotX += moveX * 0.0002f;
            rotY += moveY * 0.0002f;
            rotZ += (float)gyro.z * 0.0002f;
        }
        // --- Top screen ---
        consoleSelect(&topScreen);
        printf("\x1b[1;1H=== %s %s ===\x1b[K", APP_NAME, APP_VERSION);
        printf("\x1b[2;1HPage %d/3: %s%s\x1b[K",
            currentPage + 1,
            currentPage == PAGE_STICKS ? "Sticks" :
            currentPage == PAGE_TOUCH  ? "Touch"  : "Motion",
            currentPage == PAGE_MOTION ? " | A: Calibrate" : "");
        if (currentPage == PAGE_MOTION) {
            if (isSampling)
                printf("\x1b[4;1H[ CALIBRATING: %d%% ]\x1b[K", (sampleCounter * 100) / 30);
            else if (!isCalibrated)
                printf("\x1b[4;1H[ CALIBRATION REQUIRED ]\n\x1b[5;1HPlace flat, press (A)\x1b[K");
            else {
                // Show drift-corrected gyro + raw accel on top screen
                float gx = (float)gyro.x - gyroDriftX;
                float gy = (float)gyro.y - gyroDriftY;
                printf("\x1b[4;1HGyro(c): X:%5.0f Y:%5.0f Z:%5d\x1b[K", gx, gy, gyro.z);
                printf("\x1b[5;1HAccel:   X:%4d  Y:%4d  Z:%4d\x1b[K", accel.x, accel.y, accel.z);
            }
        } else {
            printf("\x1b[4;1HCPad:   %4d %4d | CStick: %4d %4d\x1b[K",
                cpad.dx, cpad.dy, cstick.dx, cstick.dy);
            printf("\x1b[6;1HTouch: X:%3d Y:%3d  | Keys:  %08lX\x1b[K",
                touch.px, touch.py, kHeld);
        }
        // --- Bottom screen ---
        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
        C2D_TargetClear(bot, black);
        C2D_SceneBegin(bot);
        if (currentPage == PAGE_STICKS) {
            // Circle pad (left) ----------------------------------------
            C2D_DrawCircleSolid(CPAD_CENTER_X, CPAD_CENTER_Y, 0.10f, DISPLAY_RADIUS, gray);
            C2D_DrawCircleSolid(CPAD_CENTER_X, CPAD_CENTER_Y, 0.10f, DISPLAY_RADIUS - OUTLINE, black);
            C2D_DrawLine(CPAD_CENTER_X - DISPLAY_RADIUS, CPAD_CENTER_Y, white,
                         CPAD_CENTER_X + DISPLAY_RADIUS, CPAD_CENTER_Y, white, 1.0f, 0.3f);
            C2D_DrawLine(CPAD_CENTER_X, CPAD_CENTER_Y - DISPLAY_RADIUS, white,
                         CPAD_CENTER_X, CPAD_CENTER_Y + DISPLAY_RADIUS, white, 1.0f, 0.3f);
            C2D_DrawCircleSolid(CPAD_CENTER_X, CPAD_CENTER_Y, 0.40f, 3.0f, green);
            C2D_DrawCircleSolid(
                CPAD_CENTER_X + (cpad.dx / 155.0f) * DISPLAY_RADIUS,
                CPAD_CENTER_Y - (cpad.dy / 155.0f) * DISPLAY_RADIUS,
                0.50f, DOT_RADIUS, red);
            // C-stick (right) ------------------------------------------
            C2D_DrawRectSolid(CSTICK_CENTER_X - 80, CSTICK_CENTER_Y - 80, 0.10f, 160, 160, gray);
            C2D_DrawRectSolid(CSTICK_CENTER_X - 77, CSTICK_CENTER_Y - 77, 0.10f, 154, 154, black);
            C2D_DrawLine(CSTICK_CENTER_X - 80, CSTICK_CENTER_Y, white,
                         CSTICK_CENTER_X + 80, CSTICK_CENTER_Y, white, 1.0f, 0.3f);
            C2D_DrawLine(CSTICK_CENTER_X, CSTICK_CENTER_Y - 80, white,
                         CSTICK_CENTER_X, CSTICK_CENTER_Y + 80, white, 1.0f, 0.3f);
            C2D_DrawCircleSolid(CSTICK_CENTER_X, CSTICK_CENTER_Y, 0.40f, 3.0f, green);
            C2D_DrawCircleSolid(
                CSTICK_CENTER_X + (cstick.dx / 146.0f) * DISPLAY_RADIUS,
                CSTICK_CENTER_Y - (cstick.dy / 146.0f) * DISPLAY_RADIUS,
                0.50f, DOT_RADIUS, red);
        } else if (currentPage == PAGE_TOUCH) {
            if (kHeld & KEY_TOUCH) {
                if ((int)touchTrail.size() >= TRAIL_MAX)
                    touchTrail.erase(touchTrail.begin());
                touchTrail.push_back({(float)touch.px, (float)touch.py});
                C2D_DrawCircleSolid(touch.px, touch.py, 0.9f, DOT_RADIUS, yellow);
            } else {
                touchTrail.clear();
            }
            for (size_t i = 1; i < touchTrail.size(); i++)
                C2D_DrawLine(touchTrail[i-1].x, touchTrail[i-1].y, yellow,
                             touchTrail[i].x,   touchTrail[i].y,   yellow, 2.0f, 0.5f);
        } else if (currentPage == PAGE_MOTION) {
            if (!isCalibrated) {
                C2D_DrawRectSolid(10, 10, 0.9f, 300, 220, C2D_Color32(20, 20, 20, 200));
            } else {
                // Cube rotation: integrated gyro + accelerometer gravity tilt blend
                float fX = rotX + (accel.y * 0.0015f);
                float fY = rotY + (accel.x * 0.0015f);
                // Origin shifts with acceleration for a physical jolt feel
                // Y offset 100 (not 120) to leave room for gyro bars at the bottom
                float jX = 160.0f + (accel.x / 40.0f);
                float jY = 100.0f + (accel.y / 40.0f);
                float s = 1.8f, p[8][3];
                float pscale[8]; // per-vertex perspective scale
                float focalLen = 250.0f; // perspective strength (lower = more dramatic)
                for (int i = 0; i < 8; i++) {
                    float px = cube_points[i][0] * s;
                    float py = cube_points[i][1] * s;
                    float pz = cube_points[i][2] * s;
                    float ry = py * cosf(fX) - pz * sinf(fX);
                    float rz = py * sinf(fX) + pz * cosf(fX);
                    float rx = px * cosf(fY) + rz * sinf(fY);
                    float rZfinal = -px * sinf(fY) + rz * cosf(fY);
                    // Perspective division: closer vertices spread out, farther ones compress
                    float ps = focalLen / (focalLen - rZfinal);
                    pscale[i] = ps;
                    p[i][0] = rx * ps + jX;
                    p[i][1] = ry * ps + jY;
                    p[i][2] = rZfinal;
                }
                // Sort 6 faces back-to-front by average Z for painter's algorithm
                float meanZ = 0;
                for (int i = 0; i < 8; i++) meanZ += p[i][2];
                meanZ /= 8.0f;
                float faceAvgZ[6];
                int faceOrder[6] = {0,1,2,3,4,5};
                for (int fi = 0; fi < 6; fi++) {
                    faceAvgZ[fi] = 0;
                    for (int vi = 0; vi < 4; vi++)
                        faceAvgZ[fi] += p[cubeFaces[fi][vi]][2];
                    faceAvgZ[fi] /= 4.0f;
                }
                // Simple sort back-to-front (lowest avgZ first)
                for (int i = 0; i < 5; i++)
                    for (int j = i+1; j < 6; j++)
                        if (faceAvgZ[faceOrder[i]] > faceAvgZ[faceOrder[j]]) {
                            int tmp = faceOrder[i];
                            faceOrder[i] = faceOrder[j];
                            faceOrder[j] = tmp;
                        }
                // Draw faces back-to-front; cross sits at Z_CROSS between them
                bool crossDrawn = false;
                for (int idx = 0; idx < 6; idx++) {
                    int fi = faceOrder[idx];
                    // Z-layer: spread evenly from Z_CUBE_BACK to Z_CUBE_FRONT
                    float zLayer = Z_CUBE_BACK + (Z_CUBE_FRONT - Z_CUBE_BACK) * (idx / 5.0f);
                    // Draw cross once, just before the first face in front of center
                    if (!crossDrawn && faceAvgZ[fi] > meanZ) {
                        C2D_DrawRectSolid(jX - 40, jY - 3, Z_CROSS, 80, 6, red);
                        C2D_DrawRectSolid(jX -  3, jY - 40, Z_CROSS, 6, 80, green);
                        crossDrawn = true;
                    }
                    u32 fc = faceColors[fi];
                    for (int ei = 0; ei < 4; ei++) {
                        int v0 = cubeFaces[fi][ei];
                        int v1 = cubeFaces[fi][(ei+1)%4];
                        float tw = (pscale[v0] + pscale[v1]) * 0.5f;
                        C2D_DrawLine(p[v0][0], p[v0][1], fc,
                                     p[v1][0], p[v1][1], fc, 2.5f * tw, zLayer);
                    }
                }
                // If all faces were behind center, draw cross last
                if (!crossDrawn) {
                    C2D_DrawRectSolid(jX - 40, jY - 3, Z_CROSS, 80, 6, red);
                    C2D_DrawRectSolid(jX -  3, jY - 40, Z_CROSS, 6, 80, green);
                }
                // Vertices — depth sorted, size scaled by perspective
                for (int i = 0; i < 8; i++) {
                    float vz = (p[i][2] > meanZ) ? Z_CUBE_VERTS : Z_CUBE_BACK + 0.03f;
                    C2D_DrawCircleSolid(p[i][0], p[i][1], vz, 4.0f * pscale[i], white);
                }
                // --- Gyro bars (y=190-218, fixed below cube) ---
                // X/Y use drift-corrected values; Z is raw (no Z drift correction)
                float gx = (float)gyro.x - gyroDriftX;
                float gy = (float)gyro.y - gyroDriftY;
                float gz = (float)gyro.z;
                float midX = 160.0f;
                // Center reference line
                C2D_DrawRectSolid(midX - 1, 188, 0.3f, 2, 42, gray);
                // Color indicators (left side)
                C2D_DrawRectSolid(10, 192, 0.9f, 5, 8, red);
                C2D_DrawRectSolid(10, 204, 0.9f, 5, 8, green);
                C2D_DrawRectSolid(10, 216, 0.9f, 5, 8, blue);
                // Bars — scale 12.0 matches original v1.2.4 range
                drawBar(midX, 192, 0.7f, gx, 12.0f, 8, red);
                drawBar(midX, 204, 0.7f, gy, 12.0f, 8, green);
                drawBar(midX, 216, 0.7f, gz, 12.0f, 8, blue);
            }
        }
        C3D_FrameEnd(0);
    }
    HIDUSER_DisableAccelerometer();
    HIDUSER_DisableGyroscope();
    C2D_Fini();
    C3D_Fini();
    gfxExit();
    return 0;
}
