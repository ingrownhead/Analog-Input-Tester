#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>

// Display layout
#define OUTLINE         3
#define DISPLAY_RADIUS  80.0f
#define DOT_RADIUS      6.0f

// Circle pad — left side of bottom screen
#define CPAD_CENTER_X   80.0f
#define CPAD_CENTER_Y   120.0f
#define CPAD_MAX        155.0f

// C-stick — right side of bottom screen
#define CSTICK_CENTER_X 240.0f
#define CSTICK_CENTER_Y 120.0f
#define CSTICK_MAX      146.0f

int main() {
    gfxInitDefault();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();

    // Top screen stays as text console — untouched
    PrintConsole topScreen;
    consoleInit(GFX_TOP, &topScreen);
    consoleSelect(&topScreen);

    // Bottom screen is the C2D render target
    C3D_RenderTarget* bot = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);

    // Colors
    u32 gray  = C2D_Color32(128, 128, 128, 255);
    u32 black = C2D_Color32(  0,   0,   0, 255);
    u32 red   = C2D_Color32(255,   0,   0, 255);

    // Print static labels once to top screen
    printf("=== Analog Input Tester v1.1.0-beta ===\n\n");
    printf("C-Stick X:    \n");
    printf("C-Stick Y:    \n");
    printf("\n");
    printf("Circle Pad X: \n");
    printf("Circle Pad Y: \n");
    printf("\n");
    printf("Buttons:      \n");
    printf("\n");
    printf("Press START to exit\n");

    while (aptMainLoop()) {
        hidScanInput();

        circlePosition cstick;
        hidCstickRead(&cstick);

        circlePosition cpad;
        hidCircleRead(&cpad);

        u32 keys = hidKeysHeld();

        if (keys & KEY_START) break;

        // Update top screen values — same ANSI trick as before
        printf("\x1b[3;11H%4d  ", cstick.dx);
        printf("\x1b[4;11H%4d  ", cstick.dy);
        printf("\x1b[6;11H%4d  ", cpad.dx);
        printf("\x1b[7;11H%4d  ", cpad.dy);
        printf("\x1b[9;9H%10lu  ", keys);

        // Map raw input values to screen pixel positions
        // Y is negated — joystick Y up = positive, but screen Y increases downward
        float cpadDotX   = CPAD_CENTER_X   + (cpad.dx   / CPAD_MAX)   * DISPLAY_RADIUS;
        float cpadDotY   = CPAD_CENTER_Y   - (cpad.dy   / CPAD_MAX)   * DISPLAY_RADIUS;
        float cstickDotX = CSTICK_CENTER_X + (cstick.dx / CSTICK_MAX) * DISPLAY_RADIUS;
        float cstickDotY = CSTICK_CENTER_Y - (cstick.dy / CSTICK_MAX) * DISPLAY_RADIUS;

        // --- Bottom screen rendering ---
        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
        C2D_TargetClear(bot, black);
        C2D_SceneBegin(bot);

        // Circle pad — gray circle outline
        // Trick: draw large gray circle, then slightly smaller black circle on top
        C2D_DrawCircleSolid(CPAD_CENTER_X, CPAD_CENTER_Y, 0, DISPLAY_RADIUS,          gray);
        C2D_DrawCircleSolid(CPAD_CENTER_X, CPAD_CENTER_Y, 0, DISPLAY_RADIUS - OUTLINE, black);

        // Circle pad — red position dot
        C2D_DrawCircleSolid(cpadDotX, cpadDotY, 0, DOT_RADIUS, red);

        // C-stick — gray square outline
        // Same trick: large gray rect, then inset black rect on top
        float sx = CSTICK_CENTER_X - DISPLAY_RADIUS;
        float sy = CSTICK_CENTER_Y - DISPLAY_RADIUS;
        float sw = DISPLAY_RADIUS * 2;
        C2D_DrawRectSolid(sx,            sy,            0, sw,                sw,                gray);
        C2D_DrawRectSolid(sx + OUTLINE,  sy + OUTLINE,  0, sw - OUTLINE * 2,  sw - OUTLINE * 2,  black);

        // C-stick — red position dot
        C2D_DrawCircleSolid(cstickDotX, cstickDotY, 0, DOT_RADIUS, red);

        C3D_FrameEnd(0);
        // Note: gspWaitForVBlank / gfxFlushBuffers / gfxSwapBuffers removed
        // C3D_FRAME_SYNCDRAW handles vsync and buffer swapping
    }

    C2D_Fini();
    C3D_Fini();
    gfxExit();
    return 0;
}
