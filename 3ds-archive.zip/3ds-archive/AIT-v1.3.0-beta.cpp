#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>
#include <vector>
#include <cmath>

// Constants
#define DISPLAY_RADIUS  80.0f
#define DOT_RADIUS      6.0f
#define CPAD_CENTER_X   80.0f
#define CPAD_CENTER_Y   120.0f
#define CSTICK_CENTER_X 240.0f
#define CSTICK_CENTER_Y 120.0f

enum AppPages { PAGE_STICKS, PAGE_TOUCH, PAGE_MOTION };
int currentPage = PAGE_STICKS;

struct TrailPoint { float x; float y; };
std::vector<TrailPoint> touchTrail;

// Cube points (8 corners)
float points[8][3] = {
    {-40,-40, 40}, {40,-40, 40}, {40, 40, 40}, {-40, 40, 40},
    {-40,-40,-40}, {40,-40,-40}, {40, 40,-40}, {-40, 40,-40}
};

float rotX = 0, rotY = 0, rotZ = 0;

void drawCube(float xOff, float yOff, u32 color) {
    float proj[8][2];
    for(int i=0; i<8; i++) {
        // Rotate X
        float y = points[i][1] * cos(rotX) - points[i][2] * sin(rotX);
        float z = points[i][1] * sin(rotX) + points[i][2] * cos(rotX);
        // Rotate Y
        float x = points[i][0] * cos(rotY) + z * sin(rotY);
        z = -points[i][0] * sin(rotY) + z * cos(rotY);
        // Project to 2D
        proj[i][0] = x + xOff;
        proj[i][1] = y + yOff;
    }
    // Draw the 12 edges
    for(int i=0; i<4; i++) {
        C2D_DrawLine(proj[i][0], proj[i][1], color, proj[(i+1)%4][0], proj[(i+1)%4][1], color, 2, 0.5f);
        C2D_DrawLine(proj[i+4][0], proj[i+4][1], color, proj[((i+1)%4)+4][0], proj[((i+1)%4)+4][1], color, 2, 0.5f);
        C2D_DrawLine(proj[i][0], proj[i][1], color, proj[i+4][0], proj[i+4][1], color, 2, 0.5f);
    }
}

int main() {
    gfxInitDefault();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();

    HIDUSER_EnableAccelerometer();
    HIDUSER_EnableGyroscope();

    PrintConsole topScreen;
    consoleInit(GFX_TOP, &topScreen);
    C3D_RenderTarget* bot = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);

    u32 white = C2D_Color32(255, 255, 255, 255), red = C2D_Color32(255, 0, 0, 255);
    u32 green = C2D_Color32(0, 255, 0, 255), blue = C2D_Color32(0, 128, 255, 255);

    while (aptMainLoop()) {
        hidScanInput();
        u32 kDown = hidKeysDown(), kHeld = hidKeysHeld();
        if (kDown & KEY_START) break;
        if (kDown & KEY_R) currentPage = (currentPage + 1) % 3;
        if (kDown & KEY_L) currentPage = (currentPage + 2) % 3;

        circlePosition cpad, cstick; hidCircleRead(&cpad); hidCstickRead(&cstick);
        touchPosition touch; hidTouchRead(&touch);
        accelVector accel; hidAccelRead(&accel);
        angularRate gyro; hidGyroRead(&gyro);

        // Update rotation based on Gyro
        rotX += (float)gyro.x * 0.0005f;
        rotY += (float)gyro.y * 0.0005f;
        rotZ += (float)gyro.z * 0.0005f;

        consoleSelect(&topScreen);
        printf("\x1b[1;1H=== Analog Input Tester v1.3.0-beta ===\x1b[K\nPage: %d/3\x1b[K", currentPage+1);

        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
        C2D_TargetClear(bot, C2D_Color32(0, 0, 0, 255));
        C2D_SceneBegin(bot);

        if (currentPage == PAGE_STICKS) {
            // Circle Pad
            float cpX = CPAD_CENTER_X + (cpad.dx / 155.0f) * DISPLAY_RADIUS;
            float cpY = CPAD_CENTER_Y - (cpad.dy / 155.0f) * DISPLAY_RADIUS;
            C2D_DrawCircleSolid(CPAD_CENTER_X, CPAD_CENTER_Y, 0.1f, DISPLAY_RADIUS, C2D_Color32(60,60,60,255));
            C2D_DrawCircleSolid(cpX, cpY, 0.5f, DOT_RADIUS, red);
            
            // C-Stick
            float csX = CSTICK_CENTER_X + (cstick.dx / 146.0f) * DISPLAY_RADIUS;
            float csY = CSTICK_CENTER_Y - (cstick.dy / 146.0f) * DISPLAY_RADIUS;
            C2D_DrawRectSolid(CSTICK_CENTER_X - 80, CSTICK_CENTER_Y - 80, 0.1f, 160, 160, C2D_Color32(60,60,60,255));
            C2D_DrawCircleSolid(csX, csY, 0.5f, DOT_RADIUS, red);
        } 
        else if (currentPage == PAGE_TOUCH) {
            if (kHeld & KEY_TOUCH) {
                touchTrail.push_back({(float)touch.px, (float)touch.py});
                if(touchTrail.size() > 50) touchTrail.erase(touchTrail.begin()); // Limit length
            } else { touchTrail.clear(); }
            for (size_t i = 1; i < touchTrail.size(); i++)
                C2D_DrawLine(touchTrail[i-1].x, touchTrail[i-1].y, green, touchTrail[i].x, touchTrail[i].y, green, 2, 0.5f);
        }
        else if (currentPage == PAGE_MOTION) {
            drawCube(160, 120, blue);
            // Center-out bars
            C2D_DrawRectSolid(160, 210, 0.5f, gyro.x/10, 5, red);
            C2D_DrawRectSolid(160, 220, 0.5f, gyro.y/10, 5, green);
            C2D_DrawRectSolid(160, 230, 0.5f, gyro.z/10, 5, blue);
        }

        C3D_FrameEnd(0);
    }

    HIDUSER_DisableAccelerometer(); HIDUSER_DisableGyroscope();
    C2D_Fini(); C3D_Fini(); gfxExit();
    return 0;
}
