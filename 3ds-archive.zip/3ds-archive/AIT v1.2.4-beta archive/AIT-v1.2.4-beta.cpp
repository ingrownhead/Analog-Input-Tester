#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>
#include <vector>
#include <cmath>

// Display layout constants
#define OUTLINE         3
#define DISPLAY_RADIUS  80.0f
#define DOT_RADIUS      6.0f
#define CENTER_DOT_R    3.0f
#define CROSSHAIR_W     2.0f

#define CPAD_CENTER_X   80.0f
#define CPAD_CENTER_Y   120.0f
#define CPAD_MAX        155.0f

#define CSTICK_CENTER_X 240.0f
#define CSTICK_CENTER_Y 120.0f
#define CSTICK_MAX      146.0f

// Page definitions
enum AppPages { PAGE_STICKS, PAGE_TOUCH, PAGE_MOTION };
int currentPage = PAGE_STICKS;

// Touch trail structure
struct TrailPoint { float x; float y; };
std::vector<TrailPoint> touchTrail;

// --- Cube Data ---
float cube_points[8][3] = {
    {-30,-30, 30}, {30,-30, 30}, {30, 30, 30}, {-30, 30, 30},
    {-30,-30,-30}, {30,-30,-30}, {30, 30,-30}, {-30, 30,-30}
};
float rotX = 0, rotY = 0, rotZ = 0;

int main() {
    gfxInitDefault();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();

    // Initialize Sensors
    HIDUSER_EnableAccelerometer();
    HIDUSER_EnableGyroscope();

    PrintConsole topScreen;
    consoleInit(GFX_TOP, &topScreen);
    C3D_RenderTarget* bot = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);

    u32 gray   = C2D_Color32(128, 128, 128, 255);
    u32 black  = C2D_Color32(  0,   0,   0, 255);
    u32 red    = C2D_Color32(255,   0,   0, 255);
    u32 white  = C2D_Color32(255, 255, 255, 255);
    u32 green  = C2D_Color32(  0, 255,   0, 255);
    u32 yellow = C2D_Color32(255, 255,   0, 255);
    u32 blue   = C2D_Color32(  0, 128, 255, 255);

    while (aptMainLoop()) {
        hidScanInput();
        u32 kDown = hidKeysDown();
        u32 kHeld = hidKeysHeld();

        if (kDown & KEY_START) break;

        // Tab Switching Logic
        if (kDown & KEY_R) currentPage = (currentPage + 1) % 3;
        if (kDown & KEY_L) currentPage = (currentPage + 2) % 3;

        // Data Reading
        circlePosition cstick, cpad;
        hidCstickRead(&cstick);
        hidCircleRead(&cpad);
        touchPosition touch;
        hidTouchRead(&touch);
        accelVector accel;
        hidAccelRead(&accel);
        angularRate gyro;
        hidGyroRead(&gyro);

        // Update Cube Rotation Accumulation (Gyro Spin)
        rotX += (float)gyro.x * 0.0002f;
        rotY += (float)gyro.y * 0.0002f;
        rotZ += (float)gyro.z * 0.0002f;

        // --- Top Screen Text ---
        consoleSelect(&topScreen);
        printf("\x1b[1;1H=== Analog Input Tester v1.2.4-beta ===\x1b[K");
        printf("\x1b[2;1HPage: %s (L/R to swap)\x1b[K", 
            currentPage == PAGE_STICKS ? "Sticks" : (currentPage == PAGE_TOUCH ? "Touch" : "Motion Physics"));
        
        printf("\x1b[4;1HCPad:   X:%4d Y:%4d\x1b[K", cpad.dx, cpad.dy);
        printf("\x1b[5;1HCStick: X:%4d Y:%4d\x1b[K", cstick.dx, cstick.dy);
        printf("\x1b[7;1HTouch:  X:%3d  Y:%3d\x1b[K", touch.px, touch.py);
        printf("\x1b[9;1HAccel:  X:%4d Y:%4d Z:%4d\x1b[K", accel.x, accel.y, accel.z);
        printf("\x1b[10;1HGyro:   X:%4d Y:%4d Z:%4d\x1b[K", gyro.x, gyro.y, gyro.z);
        printf("\x1b[12;1HKeys:   %08lX\x1b[K", kHeld);

        // --- Bottom Screen Rendering ---
        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
        C2D_TargetClear(bot, black);
        C2D_SceneBegin(bot);

        float z_bg = 0.1f, z_dots = 0.4f, z_lines = 0.7f, z_top = 0.9f;

        if (currentPage == PAGE_STICKS) {
            float cpX = CPAD_CENTER_X + (cpad.dx / CPAD_MAX) * DISPLAY_RADIUS;
            float cpY = CPAD_CENTER_Y - (cpad.dy / CPAD_MAX) * DISPLAY_RADIUS;
            C2D_DrawCircleSolid(CPAD_CENTER_X, CPAD_CENTER_Y, z_bg, DISPLAY_RADIUS, gray);
            C2D_DrawCircleSolid(CPAD_CENTER_X, CPAD_CENTER_Y, z_bg, DISPLAY_RADIUS - OUTLINE, black);
            C2D_DrawCircleSolid(cpX, cpY, z_dots, DOT_RADIUS, red);
            C2D_DrawRectSolid(CPAD_CENTER_X - DISPLAY_RADIUS, CPAD_CENTER_Y - 1, z_lines, DISPLAY_RADIUS * 2, 2, white);
            C2D_DrawRectSolid(CPAD_CENTER_X - 1, CPAD_CENTER_Y - DISPLAY_RADIUS, z_lines, 2, DISPLAY_RADIUS * 2, white);

            float csX = CSTICK_CENTER_X + (cstick.dx / CSTICK_MAX) * DISPLAY_RADIUS;
            float csY = CSTICK_CENTER_Y - (cstick.dy / CSTICK_MAX) * DISPLAY_RADIUS;
            C2D_DrawRectSolid(CSTICK_CENTER_X - DISPLAY_RADIUS, CSTICK_CENTER_Y - DISPLAY_RADIUS, z_bg, DISPLAY_RADIUS * 2, DISPLAY_RADIUS * 2, gray);
            C2D_DrawRectSolid(CSTICK_CENTER_X - DISPLAY_RADIUS + OUTLINE, CSTICK_CENTER_Y - DISPLAY_RADIUS + OUTLINE, z_bg, (DISPLAY_RADIUS - OUTLINE) * 2, (DISPLAY_RADIUS - OUTLINE) * 2, black);
            C2D_DrawCircleSolid(csX, csY, z_dots, DOT_RADIUS, red);
            C2D_DrawRectSolid(CSTICK_CENTER_X - DISPLAY_RADIUS, CSTICK_CENTER_Y - 1, z_lines, DISPLAY_RADIUS * 2, 2, white);
            C2D_DrawRectSolid(CSTICK_CENTER_X - 1, CSTICK_CENTER_Y - DISPLAY_RADIUS, z_lines, 2, DISPLAY_RADIUS * 2, white);
        }
        else if (currentPage == PAGE_TOUCH) {
            if (kHeld & KEY_TOUCH) {
                touchTrail.push_back({(float)touch.px, (float)touch.py});
                C2D_DrawCircleSolid(touch.px, touch.py, z_top, DOT_RADIUS, yellow);
            } else { touchTrail.clear(); }
            for (size_t i = 1; i < touchTrail.size(); i++) {
                C2D_DrawLine(touchTrail[i-1].x, touchTrail[i-1].y, yellow, touchTrail[i].x, touchTrail[i].y, yellow, 2.0f, z_dots);
            }
        }
        else if (currentPage == PAGE_MOTION) {
            // --- PHYSICS CALCULATIONS ---
            // 1. Tilt (Gravity Lean based on Accelerometer)
            float tiltX = (float)accel.y * 0.0015f; 
            float tiltY = (float)accel.x * 0.0015f;
            
            // 2. Jolt (Physical movement offset based on Accelerometer)
            float joltX = 160.0f + ((float)accel.x / 40.0f);
            float joltY = 120.0f + ((float)accel.y / 40.0f);

            // --- RENDER WIREFRAME CUBE ---
            float proj[8][2];
            float finalX = rotX + tiltX;
            float finalY = rotY + tiltY;

            for(int i=0; i<8; i++) {
                float y = cube_points[i][1] * cos(finalX) - cube_points[i][2] * sin(finalX);
                float z = cube_points[i][1] * sin(finalX) + cube_points[i][2] * cos(finalX);
                float x = cube_points[i][0] * cos(finalY) + z * sin(finalY);
                z = -cube_points[i][0] * sin(finalY) + z * cos(finalY);
                proj[i][0] = x + joltX;
                proj[i][1] = y + joltY;
            }
            for(int i=0; i<4; i++) {
                C2D_DrawLine(proj[i][0], proj[i][1], blue, proj[(i+1)%4][0], proj[(i+1)%4][1], blue, 2.0f, z_top);
                C2D_DrawLine(proj[i+4][0], proj[i+4][1], blue, proj[((i+1)%4)+4][0], proj[((i+1)%4)+4][1], blue, 2.0f, z_top);
                C2D_DrawLine(proj[i][0], proj[i][1], blue, proj[i+4][0], proj[i+4][1], blue, 2.0f, z_top);
            }
            
            // --- CENTERED GYRO BARS ---
            float midX = 160.0f;
            // Reference Line
            C2D_DrawRectSolid(midX - 1, 195, z_bg, 2, 45, gray);
            // Dynamic Bars
            C2D_DrawRectSolid(midX, 200, z_lines, (float)gyro.x / 12.0f, 8, red);   // X
            C2D_DrawRectSolid(midX, 215, z_lines, (float)gyro.y / 12.0f, 8, green); // Y
            C2D_DrawRectSolid(midX, 230, z_lines, (float)gyro.z / 12.0f, 8, blue);  // Z

            // Labels (Colored blocks for identification)
            C2D_DrawRectSolid(10, 200, z_top, 5, 8, red);   // X indicator
            C2D_DrawRectSolid(10, 215, z_top, 5, 8, green); // Y indicator
            C2D_DrawRectSolid(10, 230, z_top, 5, 8, blue);  // Z indicator
        }

        C3D_FrameEnd(0);
    }

    HIDUSER_DisableAccelerometer();
    HIDUSER_DisableGyroscope();
    C2D_Fini(); C3D_Fini(); gfxExit();
    return 0;
}
